import React, { Component } from "react";
import mahek from "../../assests/mahek.png";
import mahekimage from "../../assests/mahekimage.svg";

class banner extends Component {
  render() {
    return (
      <div>
        <div style={{ backgroundColor: "black" }}>
          <div className="container">
            <div className="row">
              <div className="col-lg-7 bann">
                <div>
                  <div className="text-white fw-bold">
                    Hello,<br />
                  </div>
                  <div className="bann1 fs-1">
                    <h1>I'm <span style={{ color: "rgb(247, 173, 77)" }}>Mahek</span></h1>npm i react-icons
                  </div>
                  <div className="bann2 fs-1 text-white fw-bold">
                    Front-end Developer
                  </div>
                  <div className="text-white mt-3 fs-5">
                    i'am a Tuinisian based front-end-developer focused on crafting clean & user-friendly experirnces,I am Passionate
                    about building excellent software that improves the lives of those around me.
                  </div>

                  <button type="button" style={{backgroundColor: "white",padding: "12px 21px",borderRadius: "20px",marginTop: "20px",}}
                  >
                    <img src={mahekimage} alt="mahekimage" style={{ height: "auto", width: "20px" }}/><span style={{ marginLeft: "10px", fontSize: "15px" }}>Hire me</span>
                  </button>

                  <div>
                    
                    
                  </div>
                </div>
              </div>
              <div className="col-lg-5">
                <img src={mahek} alt="mahek"style={{ height: "auto", width: "550px" }}/>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default banner;
