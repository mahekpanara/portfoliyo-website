import React, { Component } from "react";

class experirnce extends Component {
  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div class="experience-title fs-1 fw-bold mt-3">
              Experience
              <div class="line1 mt-2"></div>
            </div>

            <div className="exp">
              <div
                className="col-lg-5 dev"
                style={{ backgroundColor: "rgb(231 231 231)" }}>
                <div className="fs-4 ms-3 mt-2">Frontend Developer</div>
                <div className="exp1  ms-3">
                  At my startup
                  <br />
                  Moving on,to live your own litel
                </div>
              </div>
            </div>

            <div class="circle">
              <div class="circledot"></div>
              <div class="circle1"></div>
            </div>

            <div className="exp">
              <div className="col-lg-5 int">
                <div className="fs-4 ms-3 mt-2">Internship</div>
                <div className="exp1  ms-3">
                  Dwarkeshsoft privated lim.
                  <br />
                  Developed responsive web pages using HTML, CSS, JavaScript,
                  and React.js to enhance user experience.
                </div>
              </div>
            </div>

            <div class="circle">
              <div class="circledot"></div>
              <div class="circle1"></div>
            </div>

            <div className="exp">
              <div className="col-lg-5 gra">
                <div className="fs-4 ms-3 mt-2">Graduation</div>
                <div className="exp1  ms-3">
                  Saurastra University
                  <br />
                  Major in Computer Science and Engineering with a CGPA of
                  8.00,Nobody asks this but it's okay.
                </div>
              </div>
            </div>

            <div class="circle">
              <div class="circledot"></div>
              <div class="circle1"></div>
            </div>

            <div className="exp">
              <div
                className="col-lg-5"
                style={{ backgroundColor: "rgb(231 231 231)" }}>
                <div className="fs-4 ms-3 mt-2">High School</div>
                <div className="exp1  ms-3">
                  Ashadeep Vidhyalay
                  <br />
                  Luckilly covid Batchi No board exams so got 85%
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default experirnce;
