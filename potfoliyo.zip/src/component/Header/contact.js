import React, { Component } from "react";
import location from "../../assests/location.png";
import social from "../../assests/social.png";
import email from "../../assests/email.png";
import call from "../../assests/call.png";

class contact extends Component {
  render() {
    return (
      <div style={{ backgroundColor: "black",height:"800px" }} className="mt-2">
        <div className="container">
          <div className="row">
            <div className="d-flex">
              <div className="text-white">CONTACT</div>
              <div className="line2 mt-3 ms-2"></div>
            </div>
            <div className=" contact fs-4 text-white mt-2">CONTACT ME</div>
            <div className="col-lg-5">
              <div className="add mt-3">
                <div className="d-flex">
                  <div className="add1 ms-3 mt-2">
                    <img src={location} alt="location" className="location" />
                  </div>
                  <div className=" add2 mt-2 ms-3">
                    My Address
                    <div className=" add3 text-white">varachha road,surat</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg-5">
              <div className="add mt-3">
                <div className="d-flex">
                  <div className="add1 ms-3 mt-2">
                    <img src={social} alt="social" className="location" />
                  </div>
                  <div className="add2 mt-2 ms-3">
                    Social Profiles
                    <div className=" add3 text-white">varachha road,surat</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg-5">
              <div className="add mt-3">
                <div className="d-flex">
                  <div className="add1 ms-3 mt-2">
                    <img src={email} alt="email" className="location" />
                  </div>
                  <div className="add2 mt-2 ms-3">
                    Email Me
                    <div className=" add3 text-white">
                      mahekpanara4@gmail.com
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg-12">
              <form className="mt-4">
                <div className="mb-3">
                  <label htmlFor="name" className="form-label text-white">Your Name</label>
                  <input type="text" className="form-control" id="name" placeholder="Enter your name" />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label text-white">Your Email</label>
                  <input type="email" className="form-control" id="email" placeholder="Enter your email"/>
                </div>
                <div className="mb-3">
                  <label htmlFor="subject" className="form-label text-white">Subject</label>
                  <input type="text" className="form-control" id="subject" placeholder="Enter subject" />
                </div>
                <div className="mb-3">
                  <label htmlFor="message" className="form-label text-white">Your Message</label>
                  <textarea className="form-control" id="message" rows="4" placeholder="Write your message"></textarea>
                </div>
                <button type="submit" className="btn btn-primary">Send Message</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default contact;
