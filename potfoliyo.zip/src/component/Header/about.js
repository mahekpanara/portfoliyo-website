import React, { Component } from "react";

class about extends Component {
  render() {
    return (
      <div>
        <div style={{ backgroundColor: "white" }}>
          <div className="container">
            <div className="row">
              <div className="col-lg-6">
                <div className="mt-5 text-black fw-bold fs-2">
                  Any type of question & <br />
                  Discussion.
                </div>
                <div className="d-flex">
                  <div className="lets mt-3">Lets Talk</div>
                  <div className="line  ms-3"></div>
                </div>
                <div className="gmail mt-4">mahekpanara4@gmail.com</div>
                <div className="skype mt-3">Skype: mahek panara</div>
                <div className="what mt-4">Whatshapp: +917203903503</div>
              </div>
              <div className="col-lg-6">
                <div className="mt-5 text-black fw-bold fs-2">About Me</div>
                <div className="about mt-3">
                  "I am an IT student passionate about web development and
                  innovative technologies. Skilled in [mention key skills like
                  programming, problem-solving], I aim to build impactful
                  solutions and grow in the tech industry."
                </div>
                <div className="panara mt-5">
                  <span style={{ marginRight: "60px" }}>Name</span> :&nbsp;
                  &nbsp; &nbsp; &nbsp; Mahek Panara
                </div>
                <div className="email mt-4">
                  <span style={{ marginRight: "70px" }}>Email</span> :&nbsp;
                  &nbsp; &nbsp; &nbsp; mahekpanara4@gmail.com
                </div>
                <div className="website mt-4">
                  <span style={{ marginRight: "45px" }}>Website</span> :&nbsp;
                  &nbsp; &nbsp; &nbsp; mahekpanara4@gmail.com
                </div>

                <button type="button" class="cv">
                  Download CV
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default about;
