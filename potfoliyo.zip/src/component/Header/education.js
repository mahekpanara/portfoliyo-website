import React, { Component } from "react";

class education extends Component {
  render() {
    return (
      <div>
        <div class="timeline-container">
          <h1 style={{ color: "rgb(247, 173, 77)", marginTop: "20px",fontWeight:"bold" }}>
            EDUCATION
          </h1>
          <div class="timeline">
            <div class="timeline-item">
              <div class="dot"></div>
              <div class="card">
                <h4>2020 - 2022</h4>
                <h3>High School Degree</h3>
                <p>
                  The high school degree showcases my foundational education,
                  demonstrating my commitment to learning and personal growth.
                  It has equipped me with essential skills and knowledge for
                  further academic and professional pursuits.
                </p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="dot"></div>
              <div class="card">
                <h4 style={{color:"rgb(247, 173, 77)"}}>2022 - 2025</h4>
                <h3>Bachelor's Degree</h3>
                <p>
                  My bachelor's degree reflects my dedication to higher
                  education and my ability to engage in critical thinking and
                  problem-solving. It has provided me with specialized knowledge
                  and skills to pursue professional opportunities and personal
                  growth.
                </p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="dot"></div>
              <div class="card">
                <h4 style={{color:"rgb(247, 173, 77)"}}>2025 - 2027</h4>
                <h3>Master Degree</h3>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default education;
