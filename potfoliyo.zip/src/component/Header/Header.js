import React, { Component } from "react";
import logo1 from "../../assests/logo1.png";
import {Link} from "react-router-dom"

class Header extends Component {
  render() {
    return (
      <div>
        <div style={{ backgroundColor: "black"}}>
          <div className="container">
            <div className="row">
              <div className="col-lg-4">
                <img src={logo1} alt="logo" className="logo" />
              </div>
              <div className="col-lg-6 align-content-center ">
                <ul style={{ listStyleType: "none",gap:"42px" }}className="d-flex justify-content-between">
                  <li className="hh1 fs-5">
                    <Link to="" className="link-style1">HOME</Link>
                    </li>
                  <li className="hh">
                    <Link to="about" className="link-style">ABOUT</Link>
                  </li>
                  <li className="hh">
                    <Link to="skill" className="link-style">SKILL</Link>
                  </li>
                  <li className="hh">
                    <Link to="education" className="link-style">EDUCATION</Link></li>
                  <li className="hh">
                    <Link to="work" className="link-style">WORK</Link></li>
                  <li className="hh">
                    <Link to="experience" className="link-style">EXPERIENCE</Link>
                    </li>
                  <li className="hh"><Link to="Contact" className="link-style">CONTACT</Link></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Header;
