import { Component } from "react";

class Sub_skill extends Component{

    render(){
        const props = this.props;
        return(
            <div className="col-lg-4 mt-5">
            <div className="content-wrapper">
              <div className="round" style={{fontSize: "40px",color:"red"}}>
                {props.icon}
              </div>
              <div className="c">{props.field}</div>
              <div className="c1">
                {props.description}
              </div>
            </div>
          </div>
        );
    }
}
export default Sub_skill;