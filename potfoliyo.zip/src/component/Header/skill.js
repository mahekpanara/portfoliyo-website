import React, { Component } from "react";
import c from "../../assests/c.png";
import html from "../../assests/html.png";
import css from "../../assests/css.png";
import js from "../../assests/js.png";
import react from "../../assests/react.png";
import Sub_skill from "./Sub_skill";
import { FaHtml5 } from "react-icons/fa";
import { DiCss3 } from "react-icons/di";

class skill extends Component {
  render() {
    return (
      <div style={{ backgroundColor: "black" }} className="mt-2">
        <div className="container">
          <div className="row">
            <div className="skill fs-2 fw-bold text-white mt-4">
              My Skills
              <div className="linee mt-1"></div>
            </div>

            <Sub_skill
              field="C language"
              description="A powerful programming language essential for system
                  programming, embedded systems, and software development."
                icon={<FaHtml5/>}
            />
            <Sub_skill
              field="HTML"
              description="A powerful programming language essential for system
                  programming, embedded systems, and software development."
                icon={<DiCss3/>}
            />
             <Sub_skill
              field="CSS"
              description="A powerful programming language essential for system
                  programming, embedded systems, and software development."
                icon={<DiCss3/>}
            />

              <Sub_skill
              field="Boostrapt"
              description="A powerful programming language essential for system
                  programming, embedded systems, and software development."
                icon={<DiCss3/>}
            />

<Sub_skill
              field="Js"
              description="A powerful programming language essential for system
                  programming, embedded systems, and software development."
                icon={<DiCss3/>}
            />

<Sub_skill
              field="React"
              description="A powerful programming language essential for system
                  programming, embedded systems, and software development."
                icon={<DiCss3/>}
            />





            {/* { <div className="col-lg-4 mt-5">
              <div className="content-wrapper">
                <div className="round">
                  <img src={c} alt="c" className="html" />
                </div>
                <div className="c">C language</div>
                <div className="c1">
                  A powerful programming language essential for system
                  programming, embedded systems, and software development.
                </div>
              </div>
            </div>

            <div className="col-lg-4 mt-5">
              <div className="content-wrapper">
                <div className="round">
                  <img src={html} alt="html" className="html" />
                </div>
                <div className="c">HTML</div>
                <div className="c1">
                  A powerful programming language essential for system
                  programming, embedded systems, and software development.
                </div>
              </div>
            </div>

            <div className="col-lg-4 mt-5">
              <div className="content-wrapper">
                <div className="round">
                  <img src={css} alt="css" className="html" />
                </div>
                <div className="c">CSS</div>
                <div className="c1">
                  A powerful programming language essential for system
                  programming, embedded systems, and software development.
                </div>
              </div>
            </div>

            <div className="col-lg-4 mt-5">
              <div className="content-wrapper">
                <div className="round">
                  <img src={c} alt="c" className="html" />
                </div>
                <div className="c">Boostrapt</div>
                <div className="c1">
                  A powerful programming language essential for system
                  programming, embedded systems, and software development.
                </div>
              </div>
            </div>

            <div className="col-lg-4 mt-5">
              <div className="content-wrapper">
                <div className="round">
                  <img src={js} alt="js" className="html" />
                </div>
                <div className="c">Javascript</div>
                <div className="c1">
                  A powerful programming language essential for system
                  programming, embedded systems, and software development.
                </div>
              </div>
            </div>

            <div className="col-lg-4 mt-5">
              <div className="content-wrapper">
                <div className="round">
                  <img src={react} alt="react" className="html" />
                </div>
                <div className="c">React</div>
                <div className="c1">
                  A powerful programming language essential for system
                  programming, embedded systems, and software development.
                </div>
              </div>
            </div>  */}
          </div>
        </div>
      </div>
    );
  }
}

export default skill;
