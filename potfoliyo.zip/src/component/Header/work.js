import React, { Component } from "react";
import cafe from "../../assests/cafe.png";
import cemera from "../../assests/cemera.png";

class work extends Component {
  render() {
    return (
      <div>
        <div style={{ backgroundColor: "rgb(244, 244, 244)", height: "600px" }}>
          <div className="container">
            <div className="row">
              <div className="some mt-2">Some Of My Recent Works</div>
              <div className="projects fw-bold">PROJECTS</div>
              <div className="col-lg-5 mt-4">
              <img src={cafe} alt="cafe" className="img11" />
              <div className="table fs-4">Cafe Reservation</div>
              <div className="display">
              <div className="frontend">frontend:</div><div className="react">React</div>
              </div>
              <div className="display ">
              <div className="frontend mt-2">Backend:</div><div className="react mt-2">PHP</div>
              </div>
              </div>

              <div className="col-lg-5 mt-4">
              <img src={cemera} alt="cemera" className="img11" />
              <div className="table fs-4">Camera Galaxy</div>
              <div className="display">
              <div className="frontend">frontend:</div><div className="react">React</div>
              </div>
              <div className="display">
              <div className="frontend">Backend:</div><div className="react">PHP</div>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default work;
