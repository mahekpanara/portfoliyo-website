import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./component/Header/Header";
import Banner from "./component/Header/banner";
import About from "./component/Header/about";
import Skill from "./component/Header/skill";
import Experirnce from "./component/Header/experience";
import Contact from "./component/Header/contact";
import Education from "./component/Header/education";
import Work from "./component/Header/work";

function App() {
  return (
    <div className="App">
       <BrowserRouter>
          <Header />
        <Routes>
          <Route path="/" element={<Banner />} />
          <Route path="/about" element={<About />} />
          <Route path="/skill" element={<Skill />} />
          <Route path="/experience" element={<Experirnce/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/education" element={<Education/>}/>
          <Route path="/work" element={<Work/>}/>
          {/* <Route path="/props" element={<Props/>}/> */}
          
        </Routes>
       </BrowserRouter>
    </div>
  );
}

export default App;
